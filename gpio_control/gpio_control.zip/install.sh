#!/bin/bash

echo "Installing gpio control Dependencies"
sudo apt-get update
# Install the required packages via apt-get
sudo apt-get -y install

echo "Installing gpio_control"
echo "plugininstallend"