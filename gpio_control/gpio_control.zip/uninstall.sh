#!/bin/bash

# Uninstall dependendencies
# apt-get remove -y

echo "Removing gpio_control"
echo "pluginuninstallend"